package com.candyclient.mixin;

import com.candyclient.CandyLoadingOverlay;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Re-skins Minecraft's real resource reload overlay while preserving its lifecycle. */
@Mixin(SplashOverlay.class)
public abstract class SplashOverlayMixin {
    @Shadow private float progress;

    @Inject(method = "render", at = @At("TAIL"))
    private void candyclient$renderLoadingScreen(DrawContext context, int mouseX, int mouseY,
                                                  float deltaTicks, CallbackInfo ci) {
        CandyLoadingOverlay.render(context, progress);
    }
}
