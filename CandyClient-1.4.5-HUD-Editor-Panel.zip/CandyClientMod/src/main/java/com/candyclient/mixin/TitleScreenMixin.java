package com.candyclient.mixin;

import com.candyclient.CandyHubScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Routes the vanilla title-screen entry point to CandyClient's custom hub. */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin {
    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void candyclient$openHub(CallbackInfo ci) {
        MinecraftClient.getInstance().setScreen(new CandyHubScreen());
        ci.cancel();
    }
}
