package com.candyclient;

import java.util.ArrayList;
import java.util.List;

/** Practice-AI presets and their tunable behaviour. These are configuration profiles;
 * they do not automate attacks against players on multiplayer servers. */
public final class BotProfiles {
    private BotProfiles() {}
    public static final class Profile {
        public final String name, style;
        public String keybind = "R";
        public int range;
        public int turnSpeed;
        /** Selected PvP playstyle tier: LT5, LT4, LT3, LT2, or LT1. */
        public int styleTier = 5;
        public boolean enabled = false;
        public boolean strafe = true;
        public boolean defensive = true;
        public boolean combo = true;
        Profile(String name, String style, int range, int turnSpeed) {
            this.name=name; this.style=style; this.range=range; this.turnSpeed=turnSpeed;
        }
    }
    public static final List<Profile> ALL = new ArrayList<>();
    static {
        ALL.add(new Profile("Crystal PvP", "Crystal placement / pop timing", 4, 75));
        ALL.add(new Profile("Sword PvP", "Spacing / hit trading", 3, 65));
        ALL.add(new Profile("Pot PvP", "Healing / splash timing", 4, 55));
        ALL.add(new Profile("Axe & Shield PvP", "Shield pressure / disable", 3, 60));
        ALL.add(new Profile("Mace PvP", "Vertical engage / smash timing", 5, 80));
        ALL.add(new Profile("UHC PvP", "Rod / bow / melee switching", 4, 50));
        ALL.add(new Profile("Bow PvP", "Projectile spacing / leading", 18, 45));
        ALL.add(new Profile("Cart PvP", "Minecart practice / timing", 6, 60));
    }
    /** Stable IDs keep saved settings compatible if display names are edited later. */
    public static String id(int index) {
        return switch (index) {
            case 0 -> "crystal"; case 1 -> "sword"; case 2 -> "pot";
            case 3 -> "axe-shield"; case 4 -> "mace"; case 5 -> "uhc";
            case 6 -> "bow"; default -> "cart";
        };
    }
    public static void reset() { for (Profile p : ALL) p.enabled=false; }
}
