package com.candyclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.text.Text;

/** CandyClient's branded replacement for the vanilla title screen. */
public final class CandyHubScreen extends Screen {
    private static final int ORANGE = 0xFFFF963D;
    private static final String[] LABELS = {
            "SINGLEPLAYER", "MULTIPLAYER", "DONUTSMP", "MODULES",
            "SETTINGS", "CONFIGS", "COSMETICS", "EXIT"
    };

    public CandyHubScreen() { super(Text.literal("CandyClient Hub")); }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        renderThemeBackdrop(context);
        int panelW = Math.min(520, width - 32);
        int panelH = 340;
        int left = (width - panelW) / 2;
        int top = (height - panelH) / 2;
        int accent = ClientConfig.getBoolean("cosmetics.orangeAccent", true) ? ORANGE : 0xFF8796A9;
        context.fill(left - 2, top - 2, left + panelW + 2, top + panelH + 2, accent);
        context.fill(left, top, left + panelW, top + panelH, 0xF5070A0F);
        context.fill(left, top, left + panelW, top + 104, 0xFF101722);

        float pulse = (float)(0.5 + 0.5 * Math.sin(System.nanoTime() / 380_000_000.0));
        int logoGlow = blend(accent, 0xFFFFD0A3, pulse * 0.30f);
        // Theme-aware anime aura: subtle, low-cost UI animation (no textures required).
        String themeName = Modules.THEME_NAMES[Math.floorMod(Modules.theme, Modules.THEME_NAMES.length)];
        String auraLabel = switch (themeName) {
            case "Goku - Super Saiyan" -> "SUPER SAIYAN • GOLDEN AURA";
            case "Goku - Ultra Instinct" -> "ULTRA INSTINCT • SILVER AURA";
            case "Naruto - Sage Mode" -> "SAGE MODE • NATURE ENERGY";
            default -> "BLACK  •  ORANGE  •  FABRIC 1.21.11";
        };
        float aura = 0.5f + 0.5f * (float)Math.sin(System.nanoTime() / 210_000_000.0);
        int auraColor = blend(accent, 0xFFFFFFFF, 0.12f + aura * 0.30f);
        int logoY = top + 23;
        context.drawCenteredTextWithShadow(textRenderer, "CANDYCLIENT", width / 2, logoY, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, auraLabel, width / 2, top + 43, auraColor);
        // Animated aura rails and sparks frame the logo without obscuring menu controls.
        int railHalf = 48 + (int)(aura * 12);
        context.fill(width / 2 - railHalf, top + 66, width / 2 + railHalf, top + 68, logoGlow);
        context.fill(width / 2 - railHalf + 8, top + 70, width / 2 + railHalf - 8, top + 71, blend(accent, 0xFFFFFFFF, 0.08f + aura * 0.22f));
        for (int i = 0; i < 5; i++) {
            int sparkX = width / 2 - 42 + Math.floorMod((int)(System.nanoTime() / 18_000_000L) + i * 19, 84);
            int sparkY = top + 61 + (i % 2) * 8;
            context.fill(sparkX, sparkY, sparkX + 2, sparkY + 2, blend(accent, 0xFFFFFFFF, 0.25f + aura * 0.55f));
        }
        if (ClientConfig.getBoolean("cosmetics.logoBadge", true)) {
            context.fill(left + 16, top + 15, left + 44, top + 43, blend(0xFF17212D, accent, 0.35f + pulse * 0.25f));
            context.fill(left + 19, top + 18, left + 41, top + 40, accent);
            context.drawCenteredTextWithShadow(textRenderer, "C", left + 30, top + 25, 0xFFFFFFFF);
        }
        context.drawCenteredTextWithShadow(textRenderer, "WELCOME BACK", width / 2, top + 83, 0xFFB9C3D0);

        int gap = 10;
        int buttonW = (panelW - 54) / 2;
        int buttonH = 38;
        int startX = left + 18;
        int startY = top + 122;
        for (int i = 0; i < LABELS.length; i++) {
            int col = i % 2;
            int row = i / 2;
            int bx = startX + col * (buttonW + gap);
            int by = startY + row * (buttonH + 10);
            boolean hovered = mouseX >= bx && mouseX <= bx + buttonW && mouseY >= by && mouseY <= by + buttonH;
            context.fill(bx, by, bx + buttonW, by + buttonH, hovered ? 0xFF382719 : 0xFF17212D);
            context.fill(bx, by, bx + 3, by + buttonH, accent);
            if (hovered) context.fill(bx + 4, by + buttonH - 2, bx + buttonW - 4, by + buttonH, blend(0xFF382719, accent, 0.65f));
            context.drawCenteredTextWithShadow(textRenderer, LABELS[i], bx + buttonW / 2, by + 14, hovered ? logoGlow : 0xFFE8EDF4);
        }
        context.drawCenteredTextWithShadow(textRenderer, "CandyClient 1.4.1  •  Right Shift: Modules", width / 2, top + panelH - 18, 0xFF8290A2);
        super.render(context, mouseX, mouseY, delta);
    }


    /** Draws a lightweight, procedural anime-inspired backdrop. It uses no external artwork,
     * keeps the menu readable, and adapts its palette to the selected theme. */
    private void renderThemeBackdrop(DrawContext context) {
        String themeName = Modules.THEME_NAMES[Math.floorMod(Modules.theme, Modules.THEME_NAMES.length)];
        int accent = Modules.accent();
        int secondary = switch (themeName) {
            case "Goku - Super Saiyan" -> 0xFFFFE28A;
            case "Goku - Ultra Instinct" -> 0xFFDDEBFF;
            case "Naruto - Sage Mode" -> 0xFFFFB36B;
            default -> blend(accent, 0xFFFFFFFF, 0.38f);
        };
        boolean animated = ClientConfig.getBoolean("cosmetics.animatedBackdrop", true);
        int style = Math.max(0, Math.min(3, ClientConfig.getInt("cosmetics.backdropStyle", 0)));
        long tick = animated ? System.nanoTime() / 1_000_000L : 0L;
        if (style == 0 || style == 1) {
            int count = style == 0 ? 9 : 30;
            for (int i = 0; i < count; i++) {
                int speed = animated ? (12 + i % 7) : Integer.MAX_VALUE;
                int x = Math.floorMod(i * 97 + (int)(tick / speed), Math.max(1, width));
                int travel = Math.max(1, height + 24);
                int y = animated ? height - Math.floorMod((int)(tick / (20 + i % 5) + i * 41L), travel)
                        : Math.floorMod(i * 67, Math.max(1, height));
                int size = i % 5 == 0 ? 3 : 2;
                context.fill(x, y, Math.min(width, x + size), Math.min(height, y + size),
                        withAlpha((i & 1) == 0 ? accent : secondary, style == 0 ? 82 : 105));
            }
        } else if (style == 2) {
            int spacing = 36;
            for (int x = 0; x < width; x += spacing) context.fill(x, 0, x + 1, height, withAlpha(accent, 24));
            for (int y = 0; y < height; y += spacing) context.fill(0, y, width, y + 1, withAlpha(secondary, 20));
        }
        if (style != 3) {
            float pulse = animated ? 0.5f + 0.5f * (float)Math.sin(tick / 520.0) : 0.35f;
            int glow = withAlpha(blend(accent, secondary, pulse * 0.45f), 45);
            context.fill(0, 0, width, 2, glow);
            context.fill(0, height - 2, width, height, glow);
        }
    }

    private static int withAlpha(int color, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0x00FFFFFF);
    }

    private static int blend(int from, int to, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int a = (int)(((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
        int r = (int)(((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
        int g = (int)(((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
        int b = (int)((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    @Override
    public boolean mouseClicked(net.minecraft.client.gui.Click click, boolean doubled) {
        int panelW = Math.min(520, width - 32);
        int panelH = 340;
        int left = (width - panelW) / 2;
        int top = (height - panelH) / 2;
        int gap = 10;
        int buttonW = (panelW - 54) / 2;
        int buttonH = 38;
        int startX = left + 18;
        int startY = top + 122;
        double mx = click.x(), my = click.y();
        for (int i = 0; i < LABELS.length; i++) {
            int bx = startX + (i % 2) * (buttonW + gap);
            int by = startY + (i / 2) * (buttonH + 10);
            if (mx < bx || mx > bx + buttonW || my < by || my > by + buttonH) continue;
            MinecraftClient client = MinecraftClient.getInstance();
            switch (i) {
                case 0 -> client.setScreen(new SelectWorldScreen(this));
                case 1, 2 -> client.setScreen(new MultiplayerScreen(this));
                case 3 -> CandyScreen.openPage("VISUALS");
                case 4 -> CandyScreen.openPage("SETTINGS");
                case 5 -> CandyScreen.openPage("CONFIGS");
                case 6 -> client.setScreen(new CandyCosmeticsScreen(this));
                case 7 -> client.scheduleStop();
                default -> { }
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override public boolean shouldPause() { return false; }
}
