package com.candyclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** CandyClient branding drawn over the genuine Minecraft resource reload progress. */
public final class CandyLoadingOverlay {
    private static final int BLACK = 0xFF08090D;
    private static final int PANEL = 0xFF11141C;
    private static final int MUTED = 0xFF9299A8;
    private static final int ORANGE = 0xFFFF8A2A;

    private CandyLoadingOverlay() {}

    public static void render(DrawContext context, float rawProgress) {
        MinecraftClient client = MinecraftClient.getInstance();
        int width = client.getWindow().getScaledWidth();
        int height = client.getWindow().getScaledHeight();
        float progress = Math.max(0.0f, Math.min(1.0f, rawProgress));
        int percent = Math.round(progress * 100.0f);
        long now = System.currentTimeMillis();
        float pulse = 0.72f + 0.28f * (float) Math.sin(now / 260.0);

        // Full-screen branded surface; the underlying SplashOverlay still owns reload state.
        context.fill(0, 0, width, height, BLACK);
        int cardWidth = Math.min(430, Math.max(280, width - 36));
        int cardHeight = 174;
        int left = (width - cardWidth) / 2;
        int top = (height - cardHeight) / 2;
        context.fill(left, top, left + cardWidth, top + cardHeight, PANEL);
        context.fill(left, top, left + cardWidth, top + 3, ORANGE);

        int center = width / 2;
        int logoY = top + 31;
        int glow = 0xFF000000 | ((int) (0xFF * pulse) << 16) | ((int) (0x8A * pulse) << 8) | (int) (0x2A * pulse);
        context.drawCenteredTextWithShadow(client.textRenderer, Text.literal("CANDYCLIENT"), center, logoY, 0xFFFFFFFF);
        context.fill(center - 58, logoY + 18, center + 58, logoY + 20, glow);
        context.drawCenteredTextWithShadow(client.textRenderer, Text.literal("MINECRAFT 1.21.11  •  FABRIC"),
                center, logoY + 31, MUTED);

        int barWidth = cardWidth - 76;
        int barLeft = center - barWidth / 2;
        int barTop = top + 112;
        context.fill(barLeft, barTop, barLeft + barWidth, barTop + 7, 0xFF303642);
        int filled = Math.round(barWidth * progress);
        if (filled > 0) context.fill(barLeft, barTop, barLeft + filled, barTop + 7, ORANGE);

        context.drawText(client.textRenderer, Text.literal("LOADING CLIENT RESOURCES"),
                barLeft, barTop + 19, MUTED, false);
        String value = percent + "%";
        context.drawText(client.textRenderer, Text.literal(value),
                barLeft + barWidth - client.textRenderer.getWidth(value), barTop + 19, 0xFFFFFFFF, false);
        context.drawCenteredTextWithShadow(client.textRenderer, Text.literal("A little more sweet in every block."),
                center, top + 153, 0xFF737B89);
    }
}
