package com.candyclient;

import net.minecraft.client.MinecraftClient;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Properties;

/** Persistent client-side settings. The file is local to the Minecraft instance. */
public final class ClientConfig {
    private static final Properties EXTRA = new Properties();
    private static final String FILE_NAME = "candyclient.properties";
    private ClientConfig() {}
    private static Path path() {
        return MinecraftClient.getInstance().runDirectory.toPath().resolve("config").resolve(FILE_NAME);
    }
    private static String hudKey(String name) {
        return "hud." + name.toLowerCase(java.util.Locale.ROOT).replace(' ', '_').replace("replace('&', 'and')", "and").replace("/", "_") + ".";
    }

    public static void load() {
        Path file = path();
        if (!Files.isRegularFile(file)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file)) {
            p.load(in);
            EXTRA.clear();
            for (String key : p.stringPropertyNames()) if (key.startsWith("cosmetics.") || key.startsWith("ui.")) EXTRA.setProperty(key, p.getProperty(key));
            Modules.theme = clamp(parseInt(p, "theme", Modules.theme), 0, Modules.THEMES.length - 1);
            for (String name : Modules.MAP.keySet()) {
                Modules.MAP.put(name, Boolean.parseBoolean(p.getProperty("module." + name, Boolean.toString(Modules.on(name)))));
            }
            for (String name : HudLayout.names()) {
                HudLayout.Element e = HudLayout.get(name);
                String key = hudKey(name);
                int hx = parseInt(p, key + "x", e.x), hy = parseInt(p, key + "y", e.y);
                float scale;
                try { scale = Float.parseFloat(p.getProperty(key + "scale", Float.toString(e.scale))); }
                catch (NumberFormatException ignored) { scale = e.scale; }
                boolean enabled = Boolean.parseBoolean(p.getProperty(key + "enabled", Boolean.toString(e.enabled)));
                HudLayout.set(name, hx, hy, scale, enabled);
            }
            for (int i = 0; i < BotProfiles.ALL.size(); i++) {
                BotProfiles.Profile b = BotProfiles.ALL.get(i);
                String prefix = "bot." + BotProfiles.id(i) + ".", legacy = "bot." + i + ".";
                b.enabled = Boolean.parseBoolean(p.getProperty(prefix + "enabled", p.getProperty(legacy + "enabled", Boolean.toString(b.enabled))));
                b.range = clamp(parseInt(p, prefix + "range", parseInt(p, legacy + "range", b.range)), 1, 32);
                b.turnSpeed = clamp(parseInt(p, prefix + "turn", parseInt(p, legacy + "turn", b.turnSpeed)), 1, 100);
                b.styleTier = clamp(parseInt(p, prefix + "styleTier", parseInt(p, legacy + "styleTier", b.styleTier)), 1, 5);
                b.keybind = p.getProperty(prefix + "keybind", p.getProperty(legacy + "keybind", b.keybind));
                b.strafe = Boolean.parseBoolean(p.getProperty(prefix + "strafe", p.getProperty(legacy + "strafe", Boolean.toString(b.strafe))));
                b.defensive = Boolean.parseBoolean(p.getProperty(prefix + "defensive", p.getProperty(legacy + "defensive", Boolean.toString(b.defensive))));
                b.combo = Boolean.parseBoolean(p.getProperty(prefix + "combo", p.getProperty(legacy + "combo", Boolean.toString(b.combo))));
            }
        } catch (IOException | IllegalArgumentException ignored) {
            // Keep safe in-memory defaults if the user's config is missing or malformed.
        }
    }

    public static void save() {
        Path file = path(), temp = file.resolveSibling(file.getFileName() + ".tmp");
        Properties p = new Properties();
        p.setProperty("schema", "4");
        for (String key : EXTRA.stringPropertyNames()) p.setProperty(key, EXTRA.getProperty(key));
        p.setProperty("theme", Integer.toString(Modules.theme));
        for (String name : Modules.MAP.keySet()) p.setProperty("module." + name, Boolean.toString(Modules.on(name)));
        for (String name : HudLayout.names()) {
            HudLayout.Element e = HudLayout.get(name); String key = hudKey(name);
            p.setProperty(key + "x", Integer.toString(e.x));
            p.setProperty(key + "y", Integer.toString(e.y));
            p.setProperty(key + "scale", Float.toString(e.scale));
            p.setProperty(key + "enabled", Boolean.toString(e.enabled));
        }
        for (int i = 0; i < BotProfiles.ALL.size(); i++) {
            BotProfiles.Profile b = BotProfiles.ALL.get(i); String prefix = "bot." + BotProfiles.id(i) + ".";
            p.setProperty(prefix + "enabled", Boolean.toString(b.enabled));
            p.setProperty(prefix + "range", Integer.toString(b.range));
            p.setProperty(prefix + "turn", Integer.toString(b.turnSpeed));
            p.setProperty(prefix + "styleTier", Integer.toString(b.styleTier));
            p.setProperty(prefix + "keybind", b.keybind);
            p.setProperty(prefix + "strafe", Boolean.toString(b.strafe));
            p.setProperty(prefix + "defensive", Boolean.toString(b.defensive));
            p.setProperty(prefix + "combo", Boolean.toString(b.combo));
        }
        try {
            Files.createDirectories(file.getParent());
            try (OutputStream out = Files.newOutputStream(temp)) { p.store(out, "CandyClient settings - schema 5"); }
            try { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException unsupported) { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ignored) {
            try { Files.deleteIfExists(temp); } catch (IOException ignoredAgain) { }
        }
    }
    public static boolean getBoolean(String key, boolean fallback) { return Boolean.parseBoolean(EXTRA.getProperty(key, Boolean.toString(fallback))); }
    public static void setBoolean(String key, boolean value) { EXTRA.setProperty(key, Boolean.toString(value)); }
    public static int getInt(String key, int fallback) {
        try { return Integer.parseInt(EXTRA.getProperty(key, Integer.toString(fallback))); }
        catch (NumberFormatException ignored) { return fallback; }
    }
    public static void setInt(String key, int value) { EXTRA.setProperty(key, Integer.toString(value)); }

    private static int parseInt(Properties p, String key, int fallback) {
        try { return Integer.parseInt(p.getProperty(key, Integer.toString(fallback))); }
        catch (NumberFormatException ignored) { return fallback; }
    }
    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
}
