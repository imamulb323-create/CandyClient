package com.candyclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Local-only cosmetic preferences; no gameplay or server advantage is provided. */
public final class CandyCosmeticsScreen extends Screen {
    private final Screen parent;
    private boolean orangeAccent = true;
    private boolean logoBadge = true;
    private boolean animatedBackdrop = true;
    private int backdropStyle = 0;
    private static final String[] BACKDROPS = {"Aura", "Particles", "Energy Grid", "Minimal"};

    public CandyCosmeticsScreen(Screen parent) {
        super(Text.literal("CandyClient Cosmetics"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        orangeAccent = ClientConfig.getBoolean("cosmetics.orangeAccent", true);
        logoBadge = ClientConfig.getBoolean("cosmetics.logoBadge", true);
        animatedBackdrop = ClientConfig.getBoolean("cosmetics.animatedBackdrop", true);
        backdropStyle = Math.max(0, Math.min(BACKDROPS.length - 1, ClientConfig.getInt("cosmetics.backdropStyle", 0)));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int w = 390, h = 330, x = (width - w) / 2, y = (height - h) / 2;
        int accent = orangeAccent ? 0xFFFF963D : 0xFF8796A9;
        context.fill(x - 2, y - 2, x + w + 2, y + h + 2, accent);
        context.fill(x, y, x + w, y + h, 0xFF080D14);
        context.drawCenteredTextWithShadow(textRenderer, "CANDYCLIENT COSMETICS", width / 2, y + 18, 0xFFFFFFFF);
        drawOption(context, x + 22, y + 66, "Orange accent theme", orangeAccent, mouseX, mouseY);
        drawOption(context, x + 22, y + 108, "CandyClient logo badge", logoBadge, mouseX, mouseY);
        drawOption(context, x + 22, y + 150, "Animated backdrop", animatedBackdrop, mouseX, mouseY);
        context.fill(x + 22, y + 192, x + w - 22, y + 236, 0xFF172333);
        context.drawTextWithShadow(textRenderer, "Hub background", x + 32, y + 201, 0xFFE8EDF4);
        context.drawTextWithShadow(textRenderer, "Style: " + BACKDROPS[backdropStyle], x + 32, y + 217, accent);
        context.drawCenteredTextWithShadow(textRenderer, "TAP TO CHANGE", x + w - 91, y + 208, 0xFFB9C3D0);
        context.drawCenteredTextWithShadow(textRenderer, "Local visual preferences only", width / 2, y + 260, 0xFF9AA7B8);
        context.fill(x + 22, y + 282, x + w - 22, y + 312, 0xFF263241);
        context.drawCenteredTextWithShadow(textRenderer, "BACK", width / 2, y + 292, 0xFFFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    private void drawOption(DrawContext context, int x, int y, String name, boolean enabled, int mx, int my) {
        context.fill(x, y, x + 316, y + 30, 0xFF172333);
        context.drawTextWithShadow(textRenderer, name, x + 10, y + 11, 0xFFE8EDF4);
        int accent = ClientConfig.getBoolean("cosmetics.orangeAccent", true) ? 0xFFFF963D : 0xFF8796A9;
        context.fill(x + 270, y + 7, x + 306, y + 23, enabled ? accent : 0xFF465164);
        context.drawCenteredTextWithShadow(textRenderer, enabled ? "ON" : "OFF", x + 288, y + 11, 0xFFFFFFFF);
    }

    @Override
    public boolean mouseClicked(net.minecraft.client.gui.Click click, boolean doubled) {
        int x = (width - 390) / 2, y = (height - 330) / 2;
        if (click.x() >= x + 22 && click.x() <= x + 338 && click.y() >= y + 66 && click.y() <= y + 96) {
            orangeAccent = !orangeAccent;
            ClientConfig.setBoolean("cosmetics.orangeAccent", orangeAccent);
            ClientConfig.save();
            return true;
        }
        if (click.x() >= x + 22 && click.x() <= x + 338 && click.y() >= y + 108 && click.y() <= y + 138) {
            logoBadge = !logoBadge;
            ClientConfig.setBoolean("cosmetics.logoBadge", logoBadge);
            ClientConfig.save();
            return true;
        }
        if (click.x() >= x + 22 && click.x() <= x + 368 && click.y() >= y + 150 && click.y() <= y + 180) {
            animatedBackdrop = !animatedBackdrop;
            ClientConfig.setBoolean("cosmetics.animatedBackdrop", animatedBackdrop);
            ClientConfig.save();
            return true;
        }
        if (click.x() >= x + 22 && click.x() <= x + 368 && click.y() >= y + 192 && click.y() <= y + 236) {
            backdropStyle = (backdropStyle + 1) % BACKDROPS.length;
            ClientConfig.setInt("cosmetics.backdropStyle", backdropStyle);
            ClientConfig.save();
            return true;
        }
        if (click.x() >= x + 22 && click.x() <= x + 368 && click.y() >= y + 282 && click.y() <= y + 312) {
            client.setScreen(parent);
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override public boolean shouldPause() { return false; }
}
